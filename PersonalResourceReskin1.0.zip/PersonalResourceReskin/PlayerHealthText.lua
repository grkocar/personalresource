
-- Blizzard-style abbreviation data
local abbrevData = {
    breakpointData = {
        { breakpoint = 1e12, abbreviation = "B", significandDivisor = 1e10, fractionDivisor = 100, abbreviationIsGlobal = false },
        { breakpoint = 1e11, abbreviation = "B", significandDivisor = 1e9, fractionDivisor = 1, abbreviationIsGlobal = false },
        { breakpoint = 1e10, abbreviation = "B", significandDivisor = 1e8, fractionDivisor = 10, abbreviationIsGlobal = false },
        { breakpoint = 1e9, abbreviation = "B", significandDivisor = 1e7, fractionDivisor = 100, abbreviationIsGlobal = false },
        { breakpoint = 1e8, abbreviation = "M", significandDivisor = 1e6, fractionDivisor = 1, abbreviationIsGlobal = false },
        { breakpoint = 1e7, abbreviation = "M", significandDivisor = 1e5, fractionDivisor = 10, abbreviationIsGlobal = false },
        { breakpoint = 1e6, abbreviation = "M", significandDivisor = 1e4, fractionDivisor = 100, abbreviationIsGlobal = false },
        { breakpoint = 1e5, abbreviation = "K", significandDivisor = 1000, fractionDivisor = 1, abbreviationIsGlobal = false },
        { breakpoint = 1e4, abbreviation = "K", significandDivisor = 100, fractionDivisor = 10, abbreviationIsGlobal = false },
    },
}

MovablePlayerHealthTextDB = MovablePlayerHealthTextDB or {}

local CONFIG = {
    font = "Fonts\\FRIZQT__.TTF",
    fontSize = 14,
    fontFlags = "OUTLINE",
    displayStyle = MovablePlayerHealthTextDB.style or "both", -- "current", "percent", "both", "both_reverse"
    separator = " - ",
    abbreviate = true,
    showOnLogin = true,
    locked = MovablePlayerHealthTextDB.locked == nil and false or MovablePlayerHealthTextDB.locked,
}

-- Safe helpers --------------------------------------------------------------

local function safe_tonumber(v)
    if type(v) == "number" then return v end
    local ok, n = pcall(tonumber, v)
    if ok and type(n) == "number" then return n end
    return nil
end



local function SafeUnitHealthPercent(unit)
    -- Prefer UnitHealthPercent if available, but guard with pcall
    if type(UnitHealthPercent) == "function" then
        local ok, pct = pcall(UnitHealthPercent, unit)
        if ok and type(pct) == "number" then return pct end
    end

    -- Fallback to computing from UnitHealth/UnitHealthMax with guarded calls
    local ok1, cur = pcall(UnitHealth, unit)
    local ok2, max = pcall(UnitHealthMax, unit)
    if not ok1 or not ok2 or type(cur) ~= "number" or type(max) ~= "number" or max <= 0 then
        return nil
    end
    local okCmp, pct = pcall(function() return math.min(100, math.max(0, (cur / max) * 100)) end)
    if okCmp then return pct end
    return nil
end

local function SafeNumbers(unit)
    local ok1, cur = pcall(UnitHealth, unit)
    local ok2, max = pcall(UnitHealthMax, unit)
    if not ok1 or not ok2 then return nil, nil end
    if type(cur) ~= "number" or type(max) ~= "number" then return nil, nil end
    return cur, max
end

local function FormatText(style, cur, max, pct)
    -- Ensure cur/max/pct are numbers before formatting
    if type(cur) ~= "number" then cur = safe_tonumber(cur) end
    if type(max) ~= "number" then max = safe_tonumber(max) end
    if type(pct) ~= "number" then pct = safe_tonumber(pct) end
    local function abbr(val)
        if type(AbbreviateNumbers) == "function" and type(val) == "number" then
            return AbbreviateNumbers(val, abbrevData)
        end
        return tostring(val)
    end
    if style == "percent" then
        if type(pct) ~= "number" then return "?" end
        return string.format("%.0f%%", pct)
    elseif style == "both" then
        if type(cur) ~= "number" or type(pct) ~= "number" then return "?" end
        return abbr(cur or 0) .. (CONFIG.separator or " - ") .. string.format("%.0f%%", pct)
    elseif style == "both_reverse" then
        if type(cur) ~= "number" or type(pct) ~= "number" then return "?" end
        return string.format("%.0f%%", pct) .. (CONFIG.separator or " - ") .. abbr(cur or 0)
    elseif style == "currentmax" then
        if type(cur) ~= "number" or type(max) ~= "number" then return "?" end
        return abbr(cur) .. " / " .. abbr(max)
    elseif style == "current" then
        if type(cur) ~= "number" then return "?" end
        return abbr(cur)
    end
end
-- Add abbreviation style option to SavedVariables and default


-- UI: movable frame --------------------------------------------------------

local frame = CreateFrame("Frame", "MovablePlayerHealthTextFrame", UIParent)
frame:SetSize(220, 26)
frame:SetClampedToScreen(true)
frame:EnableMouse(true)
frame:SetMovable(true)

-- PlayerHealthText.lua (robust, taint-free, feature-matched to PlayerPowerText)
-- SavedVariables: PlayerHealthTextDB (declare in the .toc)

local ADDON = "PlayerHealthText"

-- Default settings
local defaults = {
    anchorToPlayerFrame = true,
    snapToPRD = false,
    offsetX = 0,
    offsetY = -160,
        offsetY = 0,
    fontChoice = "GameFontNormal",
    fontSize = 14,
    color = {1, 1, 1},
    textFormat = "currentmax", -- "currentmax", "current", "percent"
    fadeWhenFull = true,
    fadeAlpha = 0.35,
    visibleAlpha = 1.0,
    locked = false,
}

PlayerHealthTextDB = PlayerHealthTextDB or {}

local function CopyDefaults(dest, src)
    for k, v in pairs(src) do
        if type(v) == "table" then
            dest[k] = dest[k] or {}
            CopyDefaults(dest[k], v)
        else
            if dest[k] == nil then dest[k] = v end
        end
    end
end
CopyDefaults(PlayerHealthTextDB, defaults)

-- Create main frame
local frame = CreateFrame("Frame", "PlayerHealthTextFrame", UIParent, "BackdropTemplate")
frame:SetSize(160, 24)
frame:SetParent(UIParent)
frame:SetFrameStrata("MEDIUM")
frame:SetFrameLevel(200)
frame:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    edgeSize = 8,
    insets = { left = 4, right = 4, top = 4, bottom = 4 },
})
frame:SetBackdropColor(0, 0, 0, 0)
frame:SetBackdropBorderColor(1, 1, 1, 0)

-- Hide the frame immediately on load to prevent a flash if it should be hidden
frame:Hide()

local text = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
text:SetPoint("CENTER")
text:SetText("")
text:SetDrawLayer("OVERLAY", 7)

frame:EnableMouse(true)
frame:SetMovable(true)
frame:RegisterForDrag("LeftButton")

-- Safe helpers
local function SafeNumberCall(fn, ...)
    local ok, res = pcall(fn, ...)
    if not ok then return nil end
    if type(res) == "number" then return res end
    local n = tonumber(res)
    if type(n) == "number" then return n end
    return nil
end

local function SafeGetUnitHealth(unit)
    local cur = SafeNumberCall(UnitHealth, unit)
    local max = SafeNumberCall(UnitHealthMax, unit)
    return cur, max
end

function SafeSetFont(fs, fontChoice, size, fontFlags)
    if type(fontChoice) == "string" and _G[fontChoice] and type(_G[fontChoice]) == "table" then
        fs:SetFontObject(_G[fontChoice])
        pcall(function()
            local fontPath = fs:GetFont()
            if fontPath then fs:SetFont(fontPath, size, fontFlags ~= "NONE" and fontFlags or nil) end
        end)
    else
        local ok = pcall(function() fs:SetFont(fontChoice, size, fontFlags ~= "NONE" and fontFlags or nil) end)
        if not ok then
            fs:SetFontObject(GameFontNormal)
            pcall(function()
                local fontPath = fs:GetFont()
                if fontPath then fs:SetFont(fontPath, size, fontFlags ~= "NONE" and fontFlags or nil) end
            end)
        end
    end
end

function ApplyDisplaySettings()
    local db = PlayerHealthTextDB
    -- Use PlayerPowerTextDB.fontChoice if available, for unified font dropdown
    local fontChoice = (type(_G.PlayerPowerTextDB) == "table" and _G.PlayerPowerTextDB.fontChoice) or db.fontChoice or defaults.fontChoice
    -- Use fontFlags from PersonalResourceReskin config if available, else PlayerPowerTextDB, else default
    local fontFlags = (type(_G.PersonalResourceReskinDB) == "table" and _G.PersonalResourceReskinDB.profile and _G.PersonalResourceReskinDB.profile.fontFlags)
        or (type(_G.PlayerPowerTextDB) == "table" and _G.PlayerPowerTextDB.fontFlags)
        or db.fontFlags or "OUTLINE"
    SafeSetFont(text, fontChoice, db.fontSize or defaults.fontSize, fontFlags)
    -- Use PlayerPowerTextDB.color if available, for unified color picker
    local color = (type(_G.PlayerPowerTextDB) == "table" and _G.PlayerPowerTextDB.color) or db.color or defaults.color
    local r, g, b = unpack(color)
    if type(r) ~= "number" or type(g) ~= "number" or type(b) ~= "number" then
        r, g, b = unpack(defaults.color)
    end
    text:SetTextColor(r, g, b)

    -- Remove all SetPoint/anchor logic from here
    -- Only AnchorToHealthBar should control position

    -- Always set drag/mouse state based on locked
    if db.locked then
        frame:EnableMouse(false)
        frame:SetMovable(false)
    else
        frame:EnableMouse(true)
        frame:SetMovable(true)
        frame:RegisterForDrag("LeftButton")
    end
    frame:SetScript("OnDragStart", function(self)
        if PlayerHealthTextDB.locked then return end
        if type(self.StopMovingOrSizing) == "function" then pcall(self.StopMovingOrSizing, self) end
        if type(self.StartMoving) == "function" then pcall(self.StartMoving, self) end
    end)
    frame:SetScript("OnDragStop", function(self)
        if type(self.StopMovingOrSizing) == "function" then pcall(self.StopMovingOrSizing, self) end
        PlayerHealthTextDB.anchorToPlayerFrame = false
        local fx, fy = self:GetCenter()
        local ux, uy = UIParent:GetCenter()
        if fx and fy and ux and uy then
            PlayerHealthTextDB.offsetX = math.floor(fx - ux + 0.5)
            PlayerHealthTextDB.offsetY = math.floor(fy - uy + 0.5)
        end
        if type(ApplyDisplaySettings) == "function" then pcall(ApplyDisplaySettings) end
    end)

    if db.locked then
        if frame.SetBackdropColor then frame:SetBackdropColor(0, 0, 0, 0) end
        if frame.SetBackdropBorderColor then frame:SetBackdropBorderColor(1, 1, 1, 0) end
    else
        if frame.SetBackdropColor then frame:SetBackdropColor(0, 0, 0, 0.45) end
        if frame.SetBackdropBorderColor then frame:SetBackdropBorderColor(1, 1, 1, 1) end
    end
    frame:SetAlpha(db.visibleAlpha or 1.0)
end

function UpdateHealthText()
    if not UnitExists("player") then
        text:SetText("")
        frame:Hide()
        return
    end
    -- Hide health text if PRD health bar is hidden (Edit Mode or user action)
    local prd = _G.PersonalResourceDisplayFrame
    local prdHealthBar = prd and prd.HealthBarsContainer
    if prdHealthBar and not prdHealthBar:IsShown() then
        frame:Hide()
        return
    end
    if UnitIsDeadOrGhost("player") then
        text:SetText("Dead")
        frame:Show()
        return
    end
    local Unit = "player"
    local Percent = UnitHealthPercent(Unit, false, CurveConstants and CurveConstants.ScaleTo100)
    local Current = UnitHealth(Unit)
    -- Set this variable to "percent", "current", or "both" to control the display
    local displayMode = PlayerHealthTextDB and PlayerHealthTextDB.displayMode or "percent" -- default to percent
    if displayMode == "both" then
        text:SetText(FormatText("both", Current, nil, Percent))
    elseif displayMode == "current" then
        text:SetText(FormatText("current", Current, nil, Percent))
    elseif displayMode == "currentmax" then
        text:SetText(FormatText("currentmax", Current, UnitHealthMax(Unit), Percent))
    else -- percent
        text:SetText(FormatText("percent", Current, nil, Percent))
    end
    frame:Show()
end

frame:SetScript("OnDragStart", function(self)
    if PlayerHealthTextDB.locked then return end
    if type(self.StopMovingOrSizing) == "function" then pcall(self.StopMovingOrSizing, self) end
    if type(self.StartMoving) == "function" then pcall(self.StartMoving, self) end
end)
frame:SetScript("OnDragStop", function(self)
    if type(self.StopMovingOrSizing) == "function" then pcall(self.StopMovingOrSizing, self) end
    PlayerHealthTextDB.anchorToPlayerFrame = false
    local fx, fy = self:GetCenter()
    local ux, uy = UIParent:GetCenter()
    if fx and fy and ux and uy then
        PlayerHealthTextDB.offsetX = math.floor(fx - ux + 0.5)
        PlayerHealthTextDB.offsetY = math.floor(fy - uy + 0.5)
    end
    if type(ApplyDisplaySettings) == "function" then pcall(ApplyDisplaySettings) end
end)

-- Event handling
local evt = CreateFrame("Frame")
evt:RegisterUnitEvent("UNIT_HEALTH", "player")
evt:RegisterUnitEvent("UNIT_MAXHEALTH", "player")
evt:RegisterEvent("PLAYER_ENTERING_WORLD")
evt:RegisterEvent("PLAYER_UNGHOST")
evt:RegisterEvent("PLAYER_ALIVE")
evt:RegisterEvent("PLAYER_REGEN_ENABLED")
evt:RegisterEvent("PLAYER_REGEN_DISABLED")
evt:SetScript("OnEvent", function(self, event, unit)
    if unit and unit ~= "player" then return end
    UpdateHealthText()
end)

-- Slash commands
SLASH_PLAYERHEALTHTEXT1 = "/pht"
SlashCmdList["PLAYERHEALTHTEXT"] = function(msg)
    local cmd, arg = (msg or ""):match("^(%S*)%s*(.-)$")
    cmd = (cmd or ""):lower()
    arg = (arg or ""):lower()
    if cmd == "" or cmd == "toggle" then
        if frame:IsShown() then frame:Hide(); print("Player health text hidden") else UpdateHealthText(); frame:Show(); print("Player health text shown") end
        return
    end
    if cmd == "lock" then
        PlayerHealthTextDB.locked = true
        print("Player health text locked")
        ApplyDisplaySettings()
        return
    end
    if cmd == "unlock" then
        PlayerHealthTextDB.locked = false
        print("Player health text unlocked (drag to move)")
        ApplyDisplaySettings()
        return
    end
    if cmd == "displaymode" then
        if arg == "current" or arg == "percent" or arg == "both" then
            PlayerHealthTextDB.displayMode = arg
            UpdateHealthText()
            print("Player health text display mode set to", arg)
        else
            print("Usage: /pht displaymode <current|percent|both>")
        end
        return
    end
    if cmd == "resetpos" then
        PlayerHealthTextDB.point = nil
        PlayerHealthTextDB.x = nil
        PlayerHealthTextDB.y = nil
        PlayerHealthTextDB.offsetX = 0
        PlayerHealthTextDB.offsetY = -160
        frame:ClearAllPoints()
        frame:SetPoint("CENTER", UIParent, "CENTER", 0, -160)
        print("Player health text position reset")
        ApplyDisplaySettings()
        return
    end
    if cmd == "show" then UpdateHealthText(); frame:Show(); print("Player health text shown"); return end
    if cmd == "hide" then frame:Hide(); print("Player health text hidden"); return end
    print("Commands: /pht toggle | show | hide | lock | unlock | style <current|percent|currentmax> | displaymode <current|percent|both> | resetpos")
end

-- Initial state
ApplyDisplaySettings()
UpdateHealthText()

-- Remove unconditional frame:Show() on load; UpdateHealthText() will handle visibility

local function AnchorToHealthBar()
    local prd = _G.PersonalResourceDisplayFrame
    local powerBar = prd and prd.PowerBar
    local healthBar = prd and prd.HealthBarsContainer and prd.HealthBarsContainer.healthBar
    local background = powerBar and powerBar.background
    if powerBar and background and healthBar then
        frame:SetParent(powerBar)
        frame:ClearAllPoints()
        -- Move health text 1 more pixel lower
        frame:SetPoint("BOTTOM", background, "TOP", 0, -2)
    else
        frame:SetParent(UIParent)
        frame:ClearAllPoints()
        frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    end
end
AnchorToHealthBar()

-- Re-anchor on PLAYER_ENTERING_WORLD and when PowerBar moves
local function HookHealthBar()
    local prd = _G.PersonalResourceDisplayFrame
    local powerBar = prd and prd.PowerBar
    local background = powerBar and powerBar.background
    if background and not background._playerHealthTextHooked then
        background._playerHealthTextHooked = true
        hooksecurefunc(background, "SetPoint", function()
            AnchorToHealthBar()
        end)
    end
    if prd and not prd._playerHealthTextEditModeHooked then
        prd._playerHealthTextEditModeHooked = true
        hooksecurefunc(prd, "SetPoint", function()
            AnchorToHealthBar()
        end)
    end
end

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_ENTERING_WORLD" then
        AnchorToHealthBar()
        HookHealthBar()
    end
end)
