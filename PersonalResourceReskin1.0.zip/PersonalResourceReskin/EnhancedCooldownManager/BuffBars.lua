local _, ns = ...
local EnhancedCooldownManager = ns.Addon
local Util = ns.Util

---@class ECM_BuffBarsModule
local BuffBars = EnhancedCooldownManager:NewModule("BuffBars", "AceEvent-3.0")
EnhancedCooldownManager.BuffBars = BuffBars

-- Cached dynamic style index (invalidated on profile change)
local _cachedDynamicStyleIndex = nil
local _cachedDynamicStyleProfile = nil

-- Default bar color (soft gold/tan)
local FALLBACK_BAR_COLOR = { 0.85, 0.75, 0.55 }

-- Minimum bar width in pixels
local MIN_BAR_WIDTH = 200

--- Returns true if ECM should be styling BuffBars right now.
---
--- We treat ECM as disabled if the profile master toggle is off.
---@param profile ECM_Profile|table|nil
---@return boolean
local function ShouldStyle(profile)
    if not profile or profile.enabled == false then
        return false
    end

    return true
end

--- Returns current class ID and spec ID.
---@return number|nil classID, number|nil specID
local function GetCurrentClassSpec()
    local _, _, classID = UnitClass("player")
    local specID = GetSpecialization()
    return classID, specID
end

--- Ensures nested tables exist for buffBarColors storage.
---@param profile table
local function EnsureColorStorage(profile)
    if not profile.buffBarColors then
        profile.buffBarColors = {
            colors = {},
            cache = {},
            defaultColor = FALLBACK_BAR_COLOR,
        }
    end
    if not profile.buffBarColors.colors then
        profile.buffBarColors.colors = {}
    end
    if not profile.buffBarColors.cache then
        profile.buffBarColors.cache = {}
    end
    if not profile.buffBarColors.defaultColor then
        profile.buffBarColors.defaultColor = FALLBACK_BAR_COLOR
    end
end

--- Returns color for bar at index for current class/spec, or default if not set.
---@param barIndex number 1-based index in layout order
---@param profile table
---@return number r, number g, number b
local function GetBarColor(barIndex, profile)
    if not profile then
        return FALLBACK_BAR_COLOR[1], FALLBACK_BAR_COLOR[2], FALLBACK_BAR_COLOR[3]
    end

    EnsureColorStorage(profile)

    local classID, specID = GetCurrentClassSpec()
    if not classID or not specID then
        local dc = profile.buffBarColors.defaultColor or FALLBACK_BAR_COLOR
        return dc[1], dc[2], dc[3]
    end

    local colors = profile.buffBarColors.colors
    if colors[classID] and colors[classID][specID] and colors[classID][specID][barIndex] then
        local c = colors[classID][specID][barIndex]
        return c[1], c[2], c[3]
    end

    local dc = profile.buffBarColors.defaultColor or FALLBACK_BAR_COLOR
    return dc[1], dc[2], dc[3]
end

--- Updates bar cache with current bar metadata for Options UI.
---@param barIndex number
---@param spellName string|nil
---@param profile table
local function UpdateBarCache(barIndex, spellName, profile)
    if not profile or not barIndex or barIndex < 1 then
        return
    end

    EnsureColorStorage(profile)

    local classID, specID = GetCurrentClassSpec()
    if not classID or not specID then
        return
    end

    local cache = profile.buffBarColors.cache
    if not cache[classID] then
        cache[classID] = {}
    end
    if not cache[classID][specID] then
        cache[classID][specID] = {}
    end

    cache[classID][specID][barIndex] = {
        spellName = spellName,
        lastSeen = GetTime(),
    }
end

local function GetBuffBarBackground(statusBar)
    if not statusBar or not statusBar.GetRegions then
        return nil
    end

    local cached = statusBar.__ecmBarBG
    if cached and cached.IsObjectType and cached:IsObjectType("Texture") then
        return cached
    end

    for _, region in ipairs({ statusBar:GetRegions() }) do
        if region and region.IsObjectType and region:IsObjectType("Texture") then
            local atlas = region.GetAtlas and region:GetAtlas()
            if atlas == "UI-HUD-CoolDownManager-Bar-BG" or atlas == "UI-HUD-CooldownManager-Bar-BG" then
                statusBar.__ecmBarBG = region
                return region
            end
        end
    end

    return nil
end

local function BuildDynamicStyleIndex(profile)
    -- Return cached index if profile hasn't changed
    local dynamicBars = profile and profile.dynamicBars
    if _cachedDynamicStyleProfile == dynamicBars and _cachedDynamicStyleIndex then
        return _cachedDynamicStyleIndex
    end

    ---@type table<number, table>
    local map = {}

    if type(dynamicBars) ~= "table" then
        _cachedDynamicStyleIndex = map
        _cachedDynamicStyleProfile = dynamicBars
        return map
    end

    for _, cfg in ipairs(dynamicBars) do
        if type(cfg) == "table" and type(cfg.auraSpellIds) == "table" then
            for _, sid in ipairs(cfg.auraSpellIds) do
                sid = tonumber(sid)
                if sid and sid > 0 then
                    map[sid] = cfg
                end
            end
        end
    end

    _cachedDynamicStyleIndex = map
    _cachedDynamicStyleProfile = dynamicBars
    return map
end

local function TryGetChildSpellId(child)
    if not child then
        return nil
    end

    local ok, sid = pcall(child.GetSpellID, child)
    sid = ok and tonumber(sid) or nil
    -- Guard against Blizzard secret values (canaccessvalue required, not pcall)
    if sid and (type(canaccessvalue) == "function" and canaccessvalue(sid)) and sid > 0 then
        return sid
    end

    sid = tonumber(child.spellID or child.spellId or child.SpellID)
    if sid and sid > 0 then
        return sid
    end

    return nil
end

--- Hooks a child frame to re-layout when Blizzard changes its anchors.
---@param child Frame
---@param module ECM_BuffBarsModule
local function HookChildAnchoring(child, module)
    if child.__ecmAnchorHooked then
        return
    end
    child.__ecmAnchorHooked = true

    -- Hook SetPoint to detect when Blizzard re-anchors this child
    hooksecurefunc(child, "SetPoint", function()
        -- Only re-layout if we're not already running a layout
        local viewer = module:GetViewer()
        if viewer and not viewer.__ecmLayoutRunning then
            module:ScheduleLayoutUpdate()
        end
    end)

    -- Hook OnShow to ensure newly shown bars get positioned
    child:HookScript("OnShow", function()
        module:ScheduleLayoutUpdate()
    end)

    child:HookScript("OnHide", function()
        module:ScheduleLayoutUpdate()
    end)
end

--- Applies styling to a single cooldown bar child.
---@param child Frame
---@param profile table
---@param dynamicStyleBySpellId table
---@param barIndex number|nil 1-based index in layout order (for per-bar colors)
local function ApplyCooldownBarStyle(child, profile, dynamicStyleBySpellId, barIndex)
    if not (child and child.Bar and profile) then
        return
    end

    local bar = child.Bar
    if not (bar and bar.SetStatusBarTexture) then
        return
    end

    local gbl = profile.global or {}

    local spellId = TryGetChildSpellId(child)
    local dyn = (spellId and dynamicStyleBySpellId and dynamicStyleBySpellId[spellId]) or nil

    -- Use dynamic style overrides when available; otherwise fall back to global.
    local texKey = (dyn and dyn.texture) or gbl.texture
    local tex = Util.GetTexture(texKey)
    bar:SetStatusBarTexture(tex)

    -- Apply bar color from per-bar settings or default
    if bar.SetStatusBarColor and barIndex then
        local r, g, b = GetBarColor(barIndex, profile)
        bar:SetStatusBarColor(r, g, b, 1.0)
    end

    -- Update bar cache for Options UI (extract spell name safely)
    -- NOTE: Spell names from GetText() can be secret values - cannot compare them
    if barIndex then
        local spellName = nil
        if bar.Name and bar.Name.GetText then
            local ok, text = pcall(bar.Name.GetText, bar.Name)
            -- Check if we can access the value before using it
            if ok and text and (type(canaccessvalue) ~= "function" or canaccessvalue(text)) then
                spellName = text
            end
        end
        UpdateBarCache(barIndex, spellName, profile)
    end

    local bgColor = (dyn and dyn.bgColor) or Util.GetBgColor(nil, profile)
    local barBG = GetBuffBarBackground(bar)
    if barBG then
        barBG:SetTexture(Util.WHITE8)
        barBG:SetVertexColor(bgColor[1] or 0, bgColor[2] or 0, bgColor[3] or 0, bgColor[4] or 1)
        barBG:ClearAllPoints()
        barBG:SetPoint("TOPLEFT", bar, "TOPLEFT")
        barBG:SetPoint("BOTTOMRIGHT", bar, "BOTTOMRIGHT")
        barBG:SetDrawLayer("BACKGROUND", 0)
    end

    if bar.Pip then
        bar.Pip:Hide()
        bar.Pip:SetTexture(nil)
    end

    local height = Util.GetBarHeight(dyn, profile, 13)
    if height and height > 0 then
        bar:SetHeight(height)
        child:SetHeight(height)
    end

    local iconFrame = child.Icon or child.IconFrame or child.IconButton

    -- Apply visibility settings from dynamicBars config
    local dynCfg = profile.dynamicBars
    local showIcon = dynCfg == nil or dynCfg.showIcon ~= false
    local showName = dynCfg == nil or dynCfg.showSpellName ~= false
    local showDur = dynCfg == nil or dynCfg.showDuration ~= false

    if iconFrame then
        iconFrame:SetShown(showIcon)
    end
    if bar.Name then
        bar.Name:SetShown(showName)
    end
    if bar.Duration then
        bar.Duration:SetShown(showDur)
    end

    if iconFrame and height and height > 0 then
        iconFrame:SetSize(height, height)
    end

    Util.ApplyFont(bar.Name, profile)
    Util.ApplyFont(bar.Duration, profile)

    if iconFrame then
        iconFrame:ClearAllPoints()
        iconFrame:SetPoint("TOPLEFT", child, "TOPLEFT", 0, 0)
    end

    bar:ClearAllPoints()
    if iconFrame and iconFrame:IsShown() then
        bar:SetPoint("TOPLEFT", iconFrame, "TOPRIGHT", 0, 0)
    else
        bar:SetPoint("TOPLEFT", child, "TOPLEFT", 0, 0)
    end
    bar:SetPoint("TOPRIGHT", child, "TOPRIGHT", 0, 0)

    -- Mark as styled
    child.__ecmStyled = true
end

--- Returns the BuffBarCooldownViewer frame.
---@return Frame|nil
function BuffBars:GetViewer()
    return _G["BuffBarCooldownViewer"]
end

--- Resets all styled markers so bars get fully re-styled on next update.
function BuffBars:ResetStyledMarkers()
    local viewer = self:GetViewer()
    if not viewer then
        return
    end

    -- Clear anchor cache to force re-anchor
    viewer._lastAnchor = nil

    -- Clear styled markers on all children
    local children = { viewer:GetChildren() }
    for _, child in ipairs(children) do
        if child then
            child.__ecmStyled = nil
        end
    end
end

--- Hooks EditModeManagerFrame to re-apply layout on exit.
function BuffBars:HookEditMode()
    if self._editModeHooked then
        return
    end

    if not EditModeManagerFrame then
        return
    end

    self._editModeHooked = true

    hooksecurefunc(EditModeManagerFrame, "ExitEditMode", function()
        self:ResetStyledMarkers()
        self:ScheduleLayoutUpdate()
    end)

    hooksecurefunc(EditModeManagerFrame, "EnterEditMode", function()
        -- Re-apply style during edit mode so bars look correct while editing
        self:ScheduleLayoutUpdate()
    end)

    Util.Log("BuffBars", "Hooked EditModeManagerFrame")
end

--- Hooks the BuffBarCooldownViewer for automatic updates.
function BuffBars:HookViewer()
    local viewer = self:GetViewer()
    if not viewer then
        return
    end

    local profile = EnhancedCooldownManager.db and EnhancedCooldownManager.db.profile
    if not ShouldStyle(profile) then
        EnhancedCooldownManager.Util.Log("BuffBars", "HookViewer skipped - disabled")
        return
    end

    if viewer.__ecmHooked then
        return
    end
    viewer.__ecmHooked = true

    -- Hook OnShow for initial layout
    viewer:HookScript("OnShow", function(f)
        self:UpdateLayout()
    end)

    -- Hook OnSizeChanged for responsive layout
    viewer:HookScript("OnSizeChanged", function(f)
        if f.__ecmLayoutRunning then
            return
        end
        self:ScheduleLayoutUpdate()
    end)

    -- Register for UNIT_AURA to catch buff changes
    if not self._auraEventFrame then
        self._auraEventFrame = CreateFrame("Frame")
        self._auraEventFrame:RegisterEvent("UNIT_AURA")
        self._auraEventFrame:SetScript("OnEvent", function(_, event, unit)
            if unit == "player" then
                self:ScheduleRescan()
            end
        end)
    end

    -- Hook edit mode transitions
    self:HookEditMode()

    Util.Log("BuffBars", "Hooked BuffBarCooldownViewer")
end

--- Schedules a throttled layout update.
function BuffBars:ScheduleLayoutUpdate()
    if self._layoutPending then
        return
    end

    local profile = EnhancedCooldownManager.db and EnhancedCooldownManager.db.profile
    if not ShouldStyle(profile) then
        EnhancedCooldownManager.Util.Log("BuffBars", "ScheduleLayoutUpdate skipped - disabled")
        return
    end
    self._layoutPending = true

    assert(profile and profile.updateFrequency, "ECM: profile.updateFrequency missing")

    C_Timer.After(profile.updateFrequency, function()
        self._layoutPending = nil
        local viewer = self:GetViewer()
        if viewer and viewer:IsShown() then
            self:UpdateLayout()
        end
    end)
end

--- Schedules a throttled rescan for new/changed bars.
function BuffBars:ScheduleRescan()
    if self._rescanPending then
        return
    end

    local profile = EnhancedCooldownManager.db and EnhancedCooldownManager.db.profile
    if not ShouldStyle(profile) then
        EnhancedCooldownManager.Util.Log("BuffBars", "ScheduleRescan skipped - disabled")
        return
    end
    self._rescanPending = true

    assert(profile and profile.updateFrequency, "ECM: profile.updateFrequency missing")

    C_Timer.After(profile.updateFrequency, function()
        self._rescanPending = nil
        local viewer = self:GetViewer()
        if viewer and viewer:IsShown() then
            self:RescanBars()
        end
    end)
end

--- Rescans and styles any unstyled bars.
function BuffBars:RescanBars()
    local viewer = self:GetViewer()
    if not viewer then
        return
    end

    local profile = EnhancedCooldownManager.db and EnhancedCooldownManager.db.profile
    if not ShouldStyle(profile) then
        EnhancedCooldownManager.Util.Log("BuffBars", "RescanBars skipped - disabled")
        return
    end

    local children = { viewer:GetChildren() }
    local dynamicStyleBySpellId = BuildDynamicStyleIndex(profile)

    local newBarsFound = false
    local barIndex = 0
    for _, child in ipairs(children) do
        if child and child.Bar then
            -- Hook anchoring to detect when Blizzard repositions this child
            HookChildAnchoring(child, self)

            -- Track bar index for visible bars (for per-bar colors)
            local currentBarIndex = nil
            if child:IsShown() then
                barIndex = barIndex + 1
                currentBarIndex = barIndex
            end

            -- Debug: dump any text/count fields we can find on visible bars
            -- self:DebugDumpBarInfo(child)

            if not child.__ecmStyled then
                ApplyCooldownBarStyle(child, profile, dynamicStyleBySpellId, currentBarIndex)
                newBarsFound = true
            end
        end
    end

    -- Re-layout if new bars were styled
    if newBarsFound then
        self:LayoutBars()
    end
end

--- Debug helper to dump info about a bar child.
--- NOTE: All text values from Blizzard frames may be secret. Never compare them.
--- Sends detailed table data to DevTool for inspection; console output respects debug flag.
function BuffBars:DebugDumpBarInfo(child)
    if not child then
        return
    end

    local bar = child.Bar
    local iconFrame = child.Icon or child.IconFrame or child.IconButton

    -- Collect all data into a table for DevTool inspection
    local debugData = {
        childName = child.GetName and child:GetName() or "anonymous",
        barName = bar and bar.Name and bar.Name.GetText and EnhancedCooldownManager:SafeGetDebugValue(bar.Name:GetText()) or nil,
        childFields = {},
        barFields = {},
        iconInfo = {},
    }

    -- Check common field names on the child frame
    local fieldsToCheck = {
        "auraInstanceID", "auraInstanceId", "AuraInstanceID",
        "instanceID", "instanceId", "InstanceID",
        "auraID", "auraId", "AuraID",
        "buffInstanceID", "buffInstanceId",
        "spellID", "spellId", "SpellID",
    }

    for _, fieldName in ipairs(fieldsToCheck) do
        local val = child[fieldName]
        if val ~= nil then
            debugData.childFields[fieldName] = EnhancedCooldownManager:SafeGetDebugValue(val)
        end
    end

    -- Check if child has GetAuraInstanceID method
    if child.GetAuraInstanceID then
        local ok, result = pcall(child.GetAuraInstanceID, child)
        debugData.childFields["GetAuraInstanceID()"] = ok and EnhancedCooldownManager:SafeGetDebugValue(result) or "errored"
    end

    -- Check bar for these fields too
    if bar then
        for _, fieldName in ipairs(fieldsToCheck) do
            local val = bar[fieldName]
            if val ~= nil then
                debugData.barFields[fieldName] = EnhancedCooldownManager:SafeGetDebugValue(val)
            end
        end

        if bar.GetAuraInstanceID then
            local ok, result = pcall(bar.GetAuraInstanceID, bar)
            debugData.barFields["GetAuraInstanceID()"] = ok and EnhancedCooldownManager:SafeGetDebugValue(result) or "errored"
        end
    end

    -- Collect icon info
    if iconFrame then
        if iconFrame.Count and iconFrame.Count.GetText then
            debugData.iconInfo["Count"] = EnhancedCooldownManager:SafeGetDebugValue(iconFrame.Count:GetText())
        end
        if iconFrame.StackCount and iconFrame.StackCount.GetText then
            debugData.iconInfo["StackCount"] = EnhancedCooldownManager:SafeGetDebugValue(iconFrame.StackCount:GetText())
        end
    end

    if child.Count and child.Count.GetText then
        debugData.childFields["Count"] = EnhancedCooldownManager:SafeGetDebugValue(child.Count:GetText())
    end

    -- Send to DevTool/console via unified logging
    Util.Log("BuffBars", "DebugDumpBarInfo", debugData)
end

--- Positions all bar children in a vertical stack.
function BuffBars:LayoutBars()
    local viewer = self:GetViewer()
    if not viewer then
        return
    end

    viewer.__ecmLayoutRunning = true

    local children = { viewer:GetChildren() }
    local viewerWidth = viewer.GetWidth and viewer:GetWidth() or 0

    local visibleCount = 0
    local prev
    for _, child in ipairs(children) do
        -- Only include visible children with a Bar in the layout chain
        if child and child.Bar and child:IsShown() then
            visibleCount = visibleCount + 1
            child:ClearAllPoints()
            if not prev then
                child:SetPoint("TOPLEFT", viewer, "TOPLEFT", 0, 0)
                child:SetPoint("TOPRIGHT", viewer, "TOPRIGHT", 0, 0)
            else
                child:SetPoint("TOPLEFT", prev, "BOTTOMLEFT", 0, 0)
                child:SetPoint("TOPRIGHT", prev, "BOTTOMRIGHT", 0, 0)
            end
            -- Explicitly set child width to ensure it matches the viewer (with minimum)
            if child.SetWidth then
                local childWidth = math.max(viewerWidth, MIN_BAR_WIDTH)
                child:SetWidth(childWidth)
            end
            prev = child
        end
    end

    Util.Log("BuffBars", "LayoutBars complete", { visibleCount = visibleCount, viewerWidth = viewerWidth })

    viewer.__ecmLayoutRunning = nil
end

--- Updates layout: positioning, sizing, anchoring, appearance.
function BuffBars:UpdateLayout()
    local viewer = self:GetViewer()
    if not viewer then
        Util.Log("BuffBars", "UpdateLayout skipped - no viewer")
        return
    end

    local profile = EnhancedCooldownManager.db and EnhancedCooldownManager.db.profile
    if not ShouldStyle(profile) then
        Util.Log("BuffBars", "UpdateLayout skipped - disabled")
        return
    end

    local anchor = Util.GetPreferredAnchor(EnhancedCooldownManager, nil)
    if not anchor then
        Util.Log("BuffBars", "UpdateLayout skipped - no anchor")
        return
    end

    -- Get anchor width for explicit sizing
    local anchorWidth = anchor.GetWidth and anchor:GetWidth() or 0

    -- Position viewer under anchor and explicitly set width
    if viewer._lastAnchor ~= anchor or viewer._lastAnchorWidth ~= anchorWidth then
        viewer:ClearAllPoints()
        viewer:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, 0)
        viewer:SetPoint("TOPRIGHT", anchor, "BOTTOMRIGHT", 0, 0)
        -- Explicitly set width to ensure children inherit correct size (with minimum)
        local effectiveWidth = math.max(anchorWidth, MIN_BAR_WIDTH)
        viewer:SetWidth(effectiveWidth)
        viewer._lastAnchor = anchor
        viewer._lastAnchorWidth = anchorWidth
    end

    -- Style and layout all bars
    local children = { viewer:GetChildren() }
    local dynamicStyleBySpellId = BuildDynamicStyleIndex(profile)

    local barIndex = 0
    for _, child in ipairs(children) do
        if child and child.Bar then
            -- Hook anchoring to detect when Blizzard repositions this child
            HookChildAnchoring(child, self)
            -- Track bar index for visible bars (for per-bar colors)
            local currentBarIndex = nil
            if child:IsShown() then
                barIndex = barIndex + 1
                currentBarIndex = barIndex
            end
            ApplyCooldownBarStyle(child, profile, dynamicStyleBySpellId, currentBarIndex)
        end
    end

    self:LayoutBars()

    Util.Log("BuffBars", "UpdateLayout complete", {
        anchorName = anchor.GetName and anchor:GetName() or "unknown",
        anchorWidth = anchorWidth,
        childrenCount = #children
    })
end

--- Marks the buff bars as externally hidden.
---@param hidden boolean
function BuffBars:SetExternallyHidden(hidden)
    self._externallyHidden = hidden and true or false
    -- BuffBars doesn't own the viewer, so we don't hide it directly.
    -- ViewerHook manages visibility of the entire viewer stack.
end

--- Updates values for buff bars.
--- BuffBars primarily reflect Blizzard-managed buff states, so this triggers a rescan.
function BuffBars:Refresh()
    self:ScheduleRescan()
end


--- Returns cached bars for current class/spec for Options UI.
---@return table<number, ECM_BarCacheEntry> bars Indexed by bar position
function BuffBars:GetCachedBars()
    local profile = EnhancedCooldownManager.db and EnhancedCooldownManager.db.profile
    if not profile then
        return {}
    end

    EnsureColorStorage(profile)

    local classID, specID = GetCurrentClassSpec()
    if not classID or not specID then
        return {}
    end

    local cache = profile.buffBarColors.cache
    if cache[classID] and cache[classID][specID] then
        return cache[classID][specID]
    end

    return {}
end

--- Sets color for bar at index for current class/spec.
---@param barIndex number
---@param r number
---@param g number
---@param b number
function BuffBars:SetBarColor(barIndex, r, g, b)
    local profile = EnhancedCooldownManager.db and EnhancedCooldownManager.db.profile
    if not profile then
        return
    end

    EnsureColorStorage(profile)

    local classID, specID = GetCurrentClassSpec()
    if not classID or not specID then
        return
    end

    local colors = profile.buffBarColors.colors
    if not colors[classID] then
        colors[classID] = {}
    end
    if not colors[classID][specID] then
        colors[classID][specID] = {}
    end

    colors[classID][specID][barIndex] = { r, g, b }

    Util.Log("BuffBars", "SetBarColor", { barIndex = barIndex, r = r, g = g, b = b })

    -- Refresh bars to apply new color
    self:ResetStyledMarkers()
    self:ScheduleLayoutUpdate()
end

--- Resets color for bar at index to default.
---@param barIndex number
function BuffBars:ResetBarColor(barIndex)
    local profile = EnhancedCooldownManager.db and EnhancedCooldownManager.db.profile
    if not profile then
        return
    end

    EnsureColorStorage(profile)

    local classID, specID = GetCurrentClassSpec()
    if not classID or not specID then
        return
    end

    local colors = profile.buffBarColors.colors
    if colors[classID] and colors[classID][specID] then
        colors[classID][specID][barIndex] = nil
    end

    Util.Log("BuffBars", "ResetBarColor", { barIndex = barIndex })

    -- Refresh bars to apply default color
    self:ResetStyledMarkers()
    self:ScheduleLayoutUpdate()
end

--- Returns color for bar at index (wrapper for Options UI).
---@param barIndex number
---@return number r, number g, number b
function BuffBars:GetBarColor(barIndex)
    local profile = EnhancedCooldownManager.db and EnhancedCooldownManager.db.profile
    return GetBarColor(barIndex, profile)
end

--- Checks if bar at index has a custom color set.
---@param barIndex number
---@return boolean
function BuffBars:HasCustomBarColor(barIndex)
    local profile = EnhancedCooldownManager.db and EnhancedCooldownManager.db.profile
    if not profile or not profile.buffBarColors or not profile.buffBarColors.colors then
        return false
    end

    local classID, specID = GetCurrentClassSpec()
    if not classID or not specID then
        return false
    end

    local colors = profile.buffBarColors.colors
    return colors[classID] and colors[classID][specID] and colors[classID][specID][barIndex] ~= nil
end

function BuffBars:OnEnable()
    Util.Log("BuffBars", "OnEnable - module starting")
    -- Delayed initialization with retry to ensure frames exist
    local function TryInitialize()
        local profile = EnhancedCooldownManager.db and EnhancedCooldownManager.db.profile
        if not ShouldStyle(profile) then
            EnhancedCooldownManager.Util.Log("BuffBars", "OnEnable - module disabled in profile")
            return
        end
        self:HookViewer()
        self:HookEditMode()
        if self:GetViewer() then
            self:UpdateLayout()
        end
    end

    C_Timer.After(0.1, TryInitialize)
    C_Timer.After(1.0, TryInitialize)  -- Retry in case frames weren't ready
end

function BuffBars:OnDisable()
    Util.Log("BuffBars", "OnDisable - module stopping")
    if self._auraEventFrame then
        self._auraEventFrame:UnregisterAllEvents()
    end
end
