-- CustomHolyPowerBar.lua
-- Standalone custom Paladin Holy Power bar (ready to drop in)

local NUM_HOLY_POWER = 5 -- Max holy power orbs for Paladin
local HOLY_POWER_TYPE = Enum and Enum.PowerType and Enum.PowerType.HolyPower or 9 -- fallback to 9 if Enum not loaded

-- SavedVariables for position, size, and lock state
CustomHolyPowerBarDB = CustomHolyPowerBarDB or { x = 0, y = -120, orbWidth = 24, orbHeight = 24, locked = false }

-- Hide the default Holy Power bar if present

local function HideDefaultHolyPowerBar()
    local _, class = UnitClass("player")
    if class ~= "PALADIN" then return end
    -- Hide PRD/Nameplate style resource orbs/runes/holy power
    if _G.prdClassFrame then
        for i, child in ipairs({ _G.prdClassFrame:GetChildren() }) do
            if child and child:IsShown() then
                local n = child:GetName() or ""
                -- Hide any child that looks like a default orb/rune/holy power
                if n:find("HolyPower") or n:find("Rune") or child.HolyPowerFill or child.FX or child.Blur or child.DepleteFlipbook then
                    child:Hide()
                    child:SetAlpha(0)
                    if type(child.UnregisterAllEvents) == "function" then child:UnregisterAllEvents() end
                    if type(child.SetScript) == "function" then child:SetScript("OnEvent", nil) end
                end
            end
        end
        -- Optionally hide the whole prdClassFrame if it only contains default elements
        _G.prdClassFrame:Hide()
        _G.prdClassFrame:SetAlpha(0)
        if type(_G.prdClassFrame.UnregisterAllEvents) == "function" then _G.prdClassFrame:UnregisterAllEvents() end
        if type(_G.prdClassFrame.SetScript) == "function" then _G.prdClassFrame:SetScript("OnEvent", nil) end
    end
    -- PlayerFrame style
    local paladinBar = _G.PaladinPowerBar
    if paladinBar and type(paladinBar.Hide) == "function" then
        paladinBar:Hide()
        if type(paladinBar.SetAlpha) == "function" then paladinBar:SetAlpha(0) end
        if type(paladinBar.UnregisterAllEvents) == "function" then paladinBar:UnregisterAllEvents() end
        if type(paladinBar.SetScript) == "function" then paladinBar:SetScript("OnEvent", nil) end
    end
end

HideDefaultHolyPowerBar()

-- Create the custom holy power bar frame
local holyBar = CreateFrame("Frame", "CustomHolyPowerBar", UIParent)
holyBar:SetSize(180, 32)
holyBar:SetPoint("CENTER", UIParent, "CENTER", 0, -120)

holyBar.orbs = {}

for i = 1, NUM_HOLY_POWER do
    local orb = CreateFrame("Frame", nil, holyBar)
    orb:SetSize(CustomHolyPowerBarDB.orbWidth or 24, CustomHolyPowerBarDB.orbHeight or 24)
    orb:SetPoint("LEFT", holyBar, "LEFT", (i-1)*((CustomHolyPowerBarDB.orbWidth or 24)+6), 0)
    orb.bg = orb:CreateTexture(nil, "BACKGROUND")
    orb.bg:SetAllPoints()
    orb.bg:SetColorTexture(0, 0, 0, 0.5)
    orb.fill = orb:CreateTexture(nil, "ARTWORK")
    orb.fill:SetAllPoints()
    orb.fill:SetColorTexture(1, 0.85, 0.3, 1)
    orb.fill:SetAlpha(0.2)
    -- Add 1-pixel black border using four thin textures
    orb.borderTop = orb:CreateTexture(nil, "OVERLAY")
    orb.borderTop:SetColorTexture(0, 0, 0, 1)
    orb.borderTop:SetPoint("TOPLEFT", orb, "TOPLEFT", 0, 0)
    orb.borderTop:SetPoint("TOPRIGHT", orb, "TOPRIGHT", 0, 0)
    orb.borderTop:SetHeight(1)
    orb.borderBottom = orb:CreateTexture(nil, "OVERLAY")
    orb.borderBottom:SetColorTexture(0, 0, 0, 1)
    orb.borderBottom:SetPoint("BOTTOMLEFT", orb, "BOTTOMLEFT", 0, 0)
    orb.borderBottom:SetPoint("BOTTOMRIGHT", orb, "BOTTOMRIGHT", 0, 0)
    orb.borderBottom:SetHeight(1)
    orb.borderLeft = orb:CreateTexture(nil, "OVERLAY")
    orb.borderLeft:SetColorTexture(0, 0, 0, 1)
    orb.borderLeft:SetPoint("TOPLEFT", orb, "TOPLEFT", 0, 0)
    orb.borderLeft:SetPoint("BOTTOMLEFT", orb, "BOTTOMLEFT", 0, 0)
    orb.borderLeft:SetWidth(1)
    orb.borderRight = orb:CreateTexture(nil, "OVERLAY")
    orb.borderRight:SetColorTexture(0, 0, 0, 1)
    orb.borderRight:SetPoint("TOPRIGHT", orb, "TOPRIGHT", 0, 0)
    orb.borderRight:SetPoint("BOTTOMRIGHT", orb, "BOTTOMRIGHT", 0, 0)
    orb.borderRight:SetWidth(1)
    holyBar.orbs[i] = orb
end

-- Update function
local function UpdateHolyPower()
    local current = UnitPower("player", HOLY_POWER_TYPE)
    for i, orb in ipairs(holyBar.orbs) do
        if i <= current then
            orb.fill:SetAlpha(1)
        else
            orb.fill:SetAlpha(0.2)
        end
    end
end

-- Event handler
holyBar:RegisterEvent("UNIT_POWER_UPDATE")
holyBar:RegisterEvent("PLAYER_ENTERING_WORLD")
holyBar:SetScript("OnEvent", function(self, event, ...)
    if event == "UNIT_POWER_UPDATE" then
        local unit, powerType = ...
        if unit == "player" and (powerType == "HOLY_POWER" or powerType == HOLY_POWER_TYPE) then
            UpdateHolyPower()
        end
    else
        UpdateHolyPower()
    end
end)

-- Only show for Paladin
local function ShouldShowHolyBar()
    local _, class = UnitClass("player")
    return class == "PALADIN"
end

local function UpdateVisibility()
    if ShouldShowHolyBar() then
        holyBar:Show()
        UpdateHolyPower()
    else
        holyBar:Hide()
    end
end

holyBar:RegisterEvent("PLAYER_LOGIN")
holyBar:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
holyBar:SetScript("OnEvent", function(self, event, ...)
    if event == "UNIT_POWER_UPDATE" then
        local unit, powerType = ...
        if unit == "player" and (powerType == "HOLY_POWER" or powerType == HOLY_POWER_TYPE) then
            UpdateHolyPower()
        end
    else
        UpdateVisibility()
    end
end)

-- Update bar size and position
local function ApplyBarSettings()
    local spacing = 6
    local totalWidth = (CustomHolyPowerBarDB.orbWidth + spacing) * #holyBar.orbs - spacing
    holyBar:SetSize(totalWidth, CustomHolyPowerBarDB.orbHeight)
    holyBar:ClearAllPoints()
    holyBar:SetPoint("CENTER", UIParent, "CENTER", CustomHolyPowerBarDB.x, CustomHolyPowerBarDB.y)
    for i, orb in ipairs(holyBar.orbs) do
        orb:SetSize(CustomHolyPowerBarDB.orbWidth, CustomHolyPowerBarDB.orbHeight)
        orb:ClearAllPoints()
        orb:SetPoint("LEFT", holyBar, "LEFT", (i-1)*(CustomHolyPowerBarDB.orbWidth+spacing), 0)
        -- Update border positions
        orb.borderTop:SetPoint("TOPLEFT", orb, "TOPLEFT", 0, 0)
        orb.borderTop:SetPoint("TOPRIGHT", orb, "TOPRIGHT", 0, 0)
        orb.borderTop:SetHeight(1)
        orb.borderBottom:SetPoint("BOTTOMLEFT", orb, "BOTTOMLEFT", 0, 0)
        orb.borderBottom:SetPoint("BOTTOMRIGHT", orb, "BOTTOMRIGHT", 0, 0)
        orb.borderBottom:SetHeight(1)
        orb.borderLeft:SetPoint("TOPLEFT", orb, "TOPLEFT", 0, 0)
        orb.borderLeft:SetPoint("BOTTOMLEFT", orb, "BOTTOMLEFT", 0, 0)
        orb.borderLeft:SetWidth(1)
        orb.borderRight:SetPoint("TOPRIGHT", orb, "TOPRIGHT", 0, 0)
        orb.borderRight:SetPoint("BOTTOMRIGHT", orb, "BOTTOMRIGHT", 0, 0)
        orb.borderRight:SetWidth(1)
    end
end

-- Make the bar movable when unlocked
holyBar:SetMovable(true)
holyBar:EnableMouse(true)
holyBar:RegisterForDrag("LeftButton")
holyBar:SetScript("OnDragStart", function(self)
    if not CustomHolyPowerBarDB.locked then self:StartMoving() end
end)
holyBar:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local point, _, _, x, y = self:GetPoint()
    CustomHolyPowerBarDB.x = x or 0
    CustomHolyPowerBarDB.y = y or 0
end)

-- Slash commands for config
SLASH_CUSTOMHOLYPOWERBAR1 = "/chpb"
SlashCmdList["CUSTOMHOLYPOWERBAR"] = function(msg)
    local cmd, arg1, arg2 = msg:match("^(%S*)%s*(%-?%d*)%s*(%-?%d*)$")
    cmd = cmd:lower() or ""
    if cmd == "lock" then
        CustomHolyPowerBarDB.locked = true
        print("CustomHolyPowerBar locked.")
    elseif cmd == "unlock" then
        CustomHolyPowerBarDB.locked = false
        print("CustomHolyPowerBar unlocked. Drag to move.")
    elseif cmd == "size" and tonumber(arg1) and tonumber(arg2) then
        CustomHolyPowerBarDB.orbWidth = tonumber(arg1)
        CustomHolyPowerBarDB.orbHeight = tonumber(arg2)
        ApplyBarSettings()
        print("CustomHolyPowerBar orb size set to "..arg1.."x"..arg2)
    else
        print("/chpb lock | unlock | size <width> <height>")
    end
end


-- Register options as a subgroup in the main options panel
if PersonalResourceReskinPlus_Options then
    PersonalResourceReskinPlus_Options.RegisterSubOptions("CustomHolyPowerBar", {
        name = "Custom Holy Power Bar",
        type = "group",
        args = {
            lock = {
                name = "Lock Bar",
                desc = "Lock or unlock the holy power bar for dragging.",
                type = "toggle",
                get = function() return CustomHolyPowerBarDB.locked end,
                set = function(_, val)
                    CustomHolyPowerBarDB.locked = val
                    print("CustomHolyPowerBar "..(val and "locked." or "unlocked. Drag to move."))
                end,
                order = 1,
            },
            orbWidth = {
                name = "Orb Width",
                desc = "Set the width of each holy power orb.",
                type = "range",
                min = 10, max = 100, step = 1,
                get = function() return CustomHolyPowerBarDB.orbWidth end,
                set = function(_, val)
                    CustomHolyPowerBarDB.orbWidth = val
                    ApplyBarSettings()
                end,
                order = 2,
            },
            orbHeight = {
                name = "Orb Height",
                desc = "Set the height of each holy power orb.",
                type = "range",
                min = 10, max = 100, step = 1,
                get = function() return CustomHolyPowerBarDB.orbHeight end,
                set = function(_, val)
                    CustomHolyPowerBarDB.orbHeight = val
                    ApplyBarSettings()
                end,
                order = 3,
            },
        },
    })
end

-- Ensure bar settings are applied after PLAYER_LOGIN (when SavedVariables are loaded)
local function OnLoginOrReload()
    ApplyBarSettings()
end
holyBar:RegisterEvent("PLAYER_LOGIN")
holyBar:HookScript("OnEvent", function(self, event)
    if event == "PLAYER_LOGIN" then
        OnLoginOrReload()
    end
end)

ApplyBarSettings()
UpdateVisibility()
