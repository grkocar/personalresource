-- CustomDeathKnightRuneBar.lua
-- Standalone custom Death Knight Rune bar (ready to drop in)6mmm

local NUM_RUNES = 6 -- Max runes for Death Knight

-- SavedVariables for position, size, and lock state
if not CustomDeathKnightRuneBarDB or type(CustomDeathKnightRuneBarDB) ~= "table" then
    CustomDeathKnightRuneBarDB = {}
end
-- Set defaults for missing keys (do not overwrite user settings)
local function SetDefaultRuneBarDB()
    if CustomDeathKnightRuneBarDB.x == nil then CustomDeathKnightRuneBarDB.x = 0 end
    if CustomDeathKnightRuneBarDB.y == nil then CustomDeathKnightRuneBarDB.y = -120 end
    if CustomDeathKnightRuneBarDB.runeWidth == nil then CustomDeathKnightRuneBarDB.runeWidth = 24 end
    if CustomDeathKnightRuneBarDB.runeHeight == nil then CustomDeathKnightRuneBarDB.runeHeight = 24 end
    if CustomDeathKnightRuneBarDB.locked == nil then CustomDeathKnightRuneBarDB.locked = false end
    if CustomDeathKnightRuneBarDB.runeBgColor == nil then CustomDeathKnightRuneBarDB.runeBgColor = {0, 0, 0, 0.5} end
    if CustomDeathKnightRuneBarDB.gradientColor1 == nil then CustomDeathKnightRuneBarDB.gradientColor1 = {0.2, 0.8, 1, 1} end
    if CustomDeathKnightRuneBarDB.gradientColor2 == nil then CustomDeathKnightRuneBarDB.gradientColor2 = {0.2, 1, 0.8, 1} end
end
SetDefaultRuneBarDB()




-- Hide the default Rune bar and PRD runes if present
local function HideDefaultRuneBarAndPRDRunes()
    -- Classic DK rune bar
    if RuneFrame then
        RuneFrame:Hide()
        RuneFrame:SetAlpha(0)
        RuneFrame:UnregisterAllEvents()
        RuneFrame:SetScript("OnEvent", nil)
    end
    -- Retail PRD runes (Personal Resource Display)
    if prdClassFrame and prdClassFrame.Rune1 then
        for i = 1, 6 do
            local rune = prdClassFrame["Rune"..i]
            if rune then
                rune:Hide()
                rune:SetAlpha(0)
                if rune.UnregisterAllEvents then rune:UnregisterAllEvents() end
                if rune.SetScript then rune:SetScript("OnEvent", nil) end
            end
        end
    end
end

HideDefaultRuneBarAndPRDRunes()

-- Create the custom rune bar frame
local runeBar = CreateFrame("Frame", "CustomDeathKnightRuneBar", UIParent)
runeBar:SetSize(180, 32)
runeBar:SetPoint("CENTER", UIParent, "CENTER", 0, -120)

runeBar.runes = {}

for i = 1, NUM_RUNES do
    local rune = CreateFrame("Frame", nil, runeBar)
    rune:SetSize(CustomDeathKnightRuneBarDB.runeWidth, CustomDeathKnightRuneBarDB.runeHeight)
    rune:SetPoint("LEFT", runeBar, "LEFT", (i-1)*(CustomDeathKnightRuneBarDB.runeWidth+6), 0)
    rune.bg = rune:CreateTexture(nil, "BACKGROUND")
    rune.bg:SetAllPoints()
    local bg = CustomDeathKnightRuneBarDB.runeBgColor or {0, 0, 0, 0.5}
    rune.bg:SetColorTexture(bg[1], bg[2], bg[3], bg[4])
    rune.fill = rune:CreateTexture(nil, "ARTWORK")
    rune.fill:SetAllPoints()
    rune.fill:SetColorTexture(1, 1, 1, 1)
    rune.fill:SetAlpha(0.2)
    rune.borderTop = rune:CreateTexture(nil, "OVERLAY")
    rune.borderTop:SetColorTexture(0, 0, 0, 1)
    rune.borderTop:SetPoint("TOPLEFT", rune, "TOPLEFT", 0, 0)
    rune.borderTop:SetPoint("TOPRIGHT", rune, "TOPRIGHT", 0, 0)
    rune.borderTop:SetHeight(1)
    rune.borderBottom = rune:CreateTexture(nil, "OVERLAY")
    rune.borderBottom:SetColorTexture(0, 0, 0, 1)
    rune.borderBottom:SetPoint("BOTTOMLEFT", rune, "BOTTOMLEFT", 0, 0)
    rune.borderBottom:SetPoint("BOTTOMRIGHT", rune, "BOTTOMRIGHT", 0, 0)
    rune.borderBottom:SetHeight(1)
    rune.borderLeft = rune:CreateTexture(nil, "OVERLAY")
    rune.borderLeft:SetColorTexture(0, 0, 0, 1)
    rune.borderLeft:SetPoint("TOPLEFT", rune, "TOPLEFT", 0, 0)
    rune.borderLeft:SetPoint("BOTTOMLEFT", rune, "BOTTOMLEFT", 0, 0)
    rune.borderLeft:SetWidth(1)
    rune.borderRight = rune:CreateTexture(nil, "OVERLAY")
    rune.borderRight:SetColorTexture(0, 0, 0, 1)
    rune.borderRight:SetPoint("TOPRIGHT", rune, "TOPRIGHT", 0, 0)
    rune.borderRight:SetPoint("BOTTOMRIGHT", rune, "BOTTOMRIGHT", 0, 0)
    rune.borderRight:SetWidth(1)
    runeBar.runes[i] = rune
end

-- Update function
local function UpdateRunes()
    -- Gather rune states and cooldowns
    local runeReady = {}
    local runeStart = {}
    local runeDuration = {}
    for i = 1, NUM_RUNES do
        local start, duration, ready = GetRuneCooldown(i)
        runeReady[i] = ready
        runeStart[i] = start
        runeDuration[i] = duration
    end
    -- Count ready runes
    local readyCount = 0
    for i = 1, NUM_RUNES do
        if runeReady[i] then readyCount = readyCount + 1 end
    end
    -- Fill from left, empty from right: leftmost runes are filled first, rightmost are emptied first
    local c1 = CustomDeathKnightRuneBarDB.gradientColor1 or {0.2, 0.8, 1, 1}
    local c2 = CustomDeathKnightRuneBarDB.gradientColor2 or {0.2, 1, 0.8, 1}
    local bg = CustomDeathKnightRuneBarDB.runeBgColor or {0, 0, 0, 0.5}
    for i = 1, NUM_RUNES do
        local rune = runeBar.runes[i]
        rune.bg:SetColorTexture(bg[1], bg[2], bg[3], bg[4])
        -- Determine if this rune should be filled (leftmost readyCount runes are filled)
        local filled = (i <= readyCount)
        if filled then
            rune.fill:Show()
            rune.fill:SetAlpha(1)
            if rune.fill.SetVertexColor then
                rune.fill:SetVertexColor(1, 1, 1, 1)
            end
            if c1[1] == c2[1] and c1[2] == c2[2] and c1[3] == c2[3] and c1[4] == c2[4] then
                rune.fill:SetColorTexture(c1[1], c1[2], c1[3], c1[4])
            elseif rune.fill.SetGradient then
                rune.fill:SetGradient("HORIZONTAL",
                    CreateColor(c1[1], c1[2], c1[3], c1[4]),
                    CreateColor(c2[1], c2[2], c2[3], c2[4])
                )
            else
                rune.fill:SetColorTexture(c1[1], c1[2], c1[3], c1[4])
            end
        else
            rune.fill:Hide()
        end
    end
end

-- Event handler
runeBar:RegisterEvent("RUNE_POWER_UPDATE")
runeBar:RegisterEvent("PLAYER_ENTERING_WORLD")
runeBar:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
runeBar:SetScript("OnEvent", function(self, event, ...)
    UpdateRunes()
end)

-- Only show for Death Knight
local function ShouldShowRuneBar()
    local _, class = UnitClass("player")
    return class == "DEATHKNIGHT"
end

local function UpdateVisibility()
    if ShouldShowRuneBar() then
        runeBar:Show()
        UpdateRunes()
    else
        runeBar:Hide()
    end
end

-- Update bar size and position
local function ApplyBarSettings()
    local spacing = 0
    local totalWidth = (CustomDeathKnightRuneBarDB.runeWidth + spacing) * #runeBar.runes - spacing
    runeBar:SetSize(totalWidth, CustomDeathKnightRuneBarDB.runeHeight)
    runeBar:ClearAllPoints()
    runeBar:SetPoint("CENTER", UIParent, "CENTER", CustomDeathKnightRuneBarDB.x, CustomDeathKnightRuneBarDB.y)
    for i, rune in ipairs(runeBar.runes) do
        rune:SetSize(CustomDeathKnightRuneBarDB.runeWidth, CustomDeathKnightRuneBarDB.runeHeight)
        rune:ClearAllPoints()
        rune:SetPoint("LEFT", runeBar, "LEFT", (i-1)*(CustomDeathKnightRuneBarDB.runeWidth+spacing), 0)
        -- Update border positions
        rune.borderTop:SetPoint("TOPLEFT", rune, "TOPLEFT", 0, 0)
        rune.borderTop:SetPoint("TOPRIGHT", rune, "TOPRIGHT", 0, 0)
        rune.borderTop:SetHeight(1)
        rune.borderBottom:SetPoint("BOTTOMLEFT", rune, "BOTTOMLEFT", 0, 0)
        rune.borderBottom:SetPoint("BOTTOMRIGHT", rune, "BOTTOMRIGHT", 0, 0)
        rune.borderBottom:SetHeight(1)
        rune.borderLeft:SetPoint("TOPLEFT", rune, "TOPLEFT", 0, 0)
        rune.borderLeft:SetPoint("BOTTOMLEFT", rune, "BOTTOMLEFT", 0, 0)
        rune.borderLeft:SetWidth(1)
        rune.borderRight:SetPoint("TOPRIGHT", rune, "TOPRIGHT", 0, 0)
        rune.borderRight:SetPoint("BOTTOMRIGHT", rune, "BOTTOMRIGHT", 0, 0)
        rune.borderRight:SetWidth(1)
    end
end

-- Make the bar movable when unlocked
runeBar:SetMovable(true)
runeBar:EnableMouse(true)
runeBar:RegisterForDrag("LeftButton")
runeBar:SetScript("OnDragStart", function(self)
    if not CustomDeathKnightRuneBarDB.locked then self:StartMoving() end
end)
runeBar:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local point, _, _, x, y = self:GetPoint()
    CustomDeathKnightRuneBarDB.x = x or 0
    CustomDeathKnightRuneBarDB.y = y or 0

end)

-- Slash commands for config
SLASH_CUSTOMDKRUNEBAR1 = "/cdrb"
SlashCmdList["CUSTOMDKRUNEBAR"] = function(msg)
    local cmd, arg1, arg2 = msg:match("^(%S*)%s*(%-?%d*)%s*(%-?%d*)$")
    cmd = cmd:lower() or ""
    if cmd == "lock" then
        CustomDeathKnightRuneBarDB.locked = true
        print("CustomDeathKnightRuneBar locked.")
    elseif cmd == "unlock" then
        CustomDeathKnightRuneBarDB.locked = false
        print("CustomDeathKnightRuneBar unlocked. Drag to move.")
    elseif cmd == "size" and tonumber(arg1) and tonumber(arg2) then
        CustomDeathKnightRuneBarDB.runeWidth = tonumber(arg1)
        CustomDeathKnightRuneBarDB.runeHeight = tonumber(arg2)

        ApplyBarSettings()
        print("CustomDeathKnightRuneBar rune size set to "..arg1.."x"..arg2)
    else
        print("/cdrb lock | unlock | size <width> <height>")
    end
end

-- Register options as a subgroup in the main options panel
if PersonalResourceReskinPlus_Options then
    PersonalResourceReskinPlus_Options.RegisterSubOptions("CustomDeathKnightRuneBar", {
        name = "Custom Death Knight Rune Bar",
        type = "group",
        args = {
            lock = {
                name = "Lock Bar",
                desc = "Lock or unlock the rune bar for dragging.",
                type = "toggle",
                get = function() return CustomDeathKnightRuneBarDB.locked end,
                set = function(_, val)
                    CustomDeathKnightRuneBarDB.locked = val
                    print("CustomDeathKnightRuneBar "..(val and "locked." or "unlocked. Drag to move."))
                end,
                order = 1,
            },
            runeWidth = {
                name = "Rune Width",
                desc = "Set the width of each rune.",
                type = "range",
                min = 10, max = 100, step = 1,
                get = function() return CustomDeathKnightRuneBarDB.runeWidth end,
                set = function(_, val)
                    CustomDeathKnightRuneBarDB.runeWidth = val
                    ApplyBarSettings()
                end,
                order = 2,
            },
            runeHeight = {
                name = "Rune Height",
                desc = "Set the height of each rune.",
                type = "range",
                min = 10, max = 100, step = 1,
                get = function() return CustomDeathKnightRuneBarDB.runeHeight end,
                set = function(_, val)
                    CustomDeathKnightRuneBarDB.runeHeight = val
                    ApplyBarSettings()
                end,
                order = 3,
            },
            runeBgColor = {
                name = "Rune Background Color",
                desc = "Set the background color for each rune (behind the gradient fill).",
                type = "color",
                hasAlpha = true,
                order = 4,
                get = function() return unpack(CustomDeathKnightRuneBarDB.runeBgColor or {0, 0, 0, 0.5}) end,
                set = function(_, r, g, b, a)
                    CustomDeathKnightRuneBarDB.runeBgColor = {r, g, b, a}
                    UpdateRunes()
                end,
            },
            gradientColor1 = {
                name = "Rune Gradient Start",
                desc = "Set the gradient start color for the rune fill.",
                type = "color",
                hasAlpha = true,
                order = 5,
                get = function() return unpack(CustomDeathKnightRuneBarDB.gradientColor1 or {0.2, 0.8, 1, 1}) end,
                set = function(_, r, g, b, a)
                    CustomDeathKnightRuneBarDB.gradientColor1 = {r, g, b, a}
                    UpdateRunes()
                end,
            },
            gradientColor2 = {
                name = "Rune Gradient End",
                desc = "Set the gradient end color for the rune fill.",
                type = "color",
                hasAlpha = true,
                order = 6,
                get = function() return unpack(CustomDeathKnightRuneBarDB.gradientColor2 or {0.2, 1, 0.8, 1}) end,
                set = function(_, r, g, b, a)
                    CustomDeathKnightRuneBarDB.gradientColor2 = {r, g, b, a}
                    UpdateRunes()
                end,
            },
        },
    })
end

-- Ensure bar settings are applied after PLAYER_LOGIN (when SavedVariables are loaded)
local function OnLoginOrReload()
    SetDefaultRuneBarDB()

    ApplyBarSettings()
end
runeBar:RegisterEvent("PLAYER_LOGIN")
runeBar:HookScript("OnEvent", function(self, event)
    if event == "PLAYER_LOGIN" then
        OnLoginOrReload()
    end
end)

-- Apply settings on load
ApplyBarSettings()

UpdateVisibility()
