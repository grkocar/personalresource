-- Hide or make prdClassFrame and its textures transparent
local function HideOrTransparentPRDClassFrame()
    local f = _G.prdClassFrame
    if not f then
        -- Try again in 0.5s if frame not found
        C_Timer.After(0.5, HideOrTransparentPRDClassFrame)
        return
    end
    -- Option 1: Hide the frame completely
    f:Hide()
    -- Option 2: Make the frame and its textures fully transparent
    f:SetAlpha(0)
    if f.Background then f.Background:SetAlpha(0) end
    if f.Glow then f.Glow:SetAlpha(0) end
    if f.ThinGlow then f.ThinGlow:SetAlpha(0) end
    if f.ActiveTexture then f.ActiveTexture:SetAlpha(0) end
end

-- Run on PLAYER_ENTERING_WORLD to ensure frame exists
local frame = CreateFrame("Frame")
frame:RegisterEvent("PLAYER_ENTERING_WORLD")
frame:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
frame:RegisterEvent("UNIT_DISPLAYPOWER")
frame:RegisterEvent("PLAYER_TALENT_UPDATE")
frame:RegisterEvent("PLAYER_REGEN_ENABLED")
frame:RegisterEvent("PLAYER_REGEN_DISABLED")
frame:SetScript("OnEvent", function()
    C_Timer.After(0.1, HideOrTransparentPRDClassFrame)
end)
